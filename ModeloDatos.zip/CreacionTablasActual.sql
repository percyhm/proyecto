/*==============================================================*/
/* DBMS name:      ORACLE Version 11g                           */
/* Created on:     16/01/2020 10:48:50                          */
/*==============================================================*/


create sequence SECAB_ACE
increment by 1
start with 1
 maxvalue 1.000E+27
nocycle
 nocache
noorder;

grant SELECT on SECAB_ACE to RLDAIN;

create sequence SENUMACE0190300
increment by 1
start with 1
 maxvalue 1.000E+27
nocycle
 nocache
noorder;

grant SELECT on SENUMACE0190300 to RLDAIN;

create sequence SEPROCESOACE
increment by 1
start with 1
 maxvalue 1.000E+27
nocycle
 nocache
noorder;

grant SELECT on SEPROCESOACE to RLDAIN;

/*==============================================================*/
/* Table: TXX10ASIGNACIONACE                                    */
/*==============================================================*/
create table USADDAIN.TXX10ASIGNACIONACE 
(
   NUM_SECASIGNACION    NUMBER(6)            not null,
   NUM_SECACE           NUMBER(12)           not null,
   COD_FUNCIONARIO      VARCHAR2(6),
   FEC_ASIGNACION       DATE,
   FEC_INICIOREV        DATE,
   FEC_FINREV           DATE,
   COD_ESTADOREV        VARCHAR2(2),
   DES_MOTIVO           VARCHAR2(1000),
   COD_USUREGIS         VARCHAR2(19)         default ' ',
   FEC_REGIS            DATE                 default SYSDATE,
   COD_USUMODIF         VARCHAR2(19)         default ' ',
   FEC_MODIF            DATE                 default TO_DATE( '01/01/0001','DD/MM/YYYY'),
   IND_DEL              CHAR(1)              default '0'
);

comment on table USADDAIN.TXX10ASIGNACIONACE is
'Asignacion Especialista';

comment on column USADDAIN.TXX10ASIGNACIONACE.NUM_SECASIGNACION is
'Secuencia de asignaci�n';

comment on column USADDAIN.TXX10ASIGNACIONACE.COD_FUNCIONARIO is
'C�digo de funcionario';

comment on column USADDAIN.TXX10ASIGNACIONACE.FEC_ASIGNACION is
'Fecha de asignaci�n';

comment on column USADDAIN.TXX10ASIGNACIONACE.FEC_INICIOREV is
'Fecha de inicio de revision';

comment on column USADDAIN.TXX10ASIGNACIONACE.FEC_FINREV is
'Fecha fin de revisi�n';

comment on column USADDAIN.TXX10ASIGNACIONACE.COD_ESTADOREV is
'Estado de la revisi�n';

comment on column USADDAIN.TXX10ASIGNACIONACE.DES_MOTIVO is
'Motivo de la asignaci�n';

comment on column USADDAIN.TXX10ASIGNACIONACE.COD_USUREGIS is
'Usuario Registro';

comment on column USADDAIN.TXX10ASIGNACIONACE.FEC_REGIS is
'Fecha Registro';

comment on column USADDAIN.TXX10ASIGNACIONACE.COD_USUMODIF is
'Usuario de modificaci�n';

comment on column USADDAIN.TXX10ASIGNACIONACE.FEC_MODIF is
'Fecha de modificaci�n';

comment on column USADDAIN.TXX10ASIGNACIONACE.IND_DEL is
'Indicador Eliminado';

alter table USADDAIN.TXX10ASIGNACIONACE
   add constraint PK_TXX10 primary key (NUM_SECASIGNACION, NUM_SECACE);

/*==============================================================*/
/* Index: RELATIONSHIP_14_FK                                    */
/*==============================================================*/
create index USADDAIN.RELATIONSHIP_14_FK on USADDAIN.TXX10ASIGNACIONACE (
   NUM_SECACE ASC
);

grant INSERT,SELECT,UPDATE on USADDAIN.TXX10ASIGNACIONACE to RLDAIN;

grant SELECT on USADDAIN.TXX10ASIGNACIONACE to RLDAINC;

/*==============================================================*/
/* Table: TXX12SUSTENTOACE                                      */
/*==============================================================*/
create table USADDAIN.TXX12SUSTENTOACE 
(
   NUM_SECACE           NUMBER(12)           not null,
   NUM_SECSUSTENTO      NUMBER(6)            not null,
   COD_FRAUDE           VARCHAR2(2),
   COD_MOTIVO           VARCHAR2(50),
   DES_JUSTIFICACION    VARCHAR2(2000),
   COD_MOMENTO          VARCHAR2(4),
   COD_USUREGIS         VARCHAR2(19)         default ' ',
   FEC_REGIS            DATE                 default SYSDATE,
   COD_USUMODIF         VARCHAR2(19)         default ' ',
   FEC_MODIF            DATE                 default TO_DATE( '01/01/0001','DD/MM/YYYY'),
   IND_DEL              CHAR(1)              default '0'
);

comment on table USADDAIN.TXX12SUSTENTOACE is
'Motivo de Sustento';

comment on column USADDAIN.TXX12SUSTENTOACE.COD_FRAUDE is
'C�digo de Fraude';

comment on column USADDAIN.TXX12SUSTENTOACE.COD_MOTIVO is
'C�digo motivo de sustento';

comment on column USADDAIN.TXX12SUSTENTOACE.DES_JUSTIFICACION is
'Texto de justificaci�n ingresado';

comment on column USADDAIN.TXX12SUSTENTOACE.COD_MOMENTO is
'Momento de Comunicaci�n';

comment on column USADDAIN.TXX12SUSTENTOACE.COD_USUREGIS is
'Usuario Registro';

comment on column USADDAIN.TXX12SUSTENTOACE.FEC_REGIS is
'Fecha Registro';

comment on column USADDAIN.TXX12SUSTENTOACE.COD_USUMODIF is
'Usuario de modificaci�n';

comment on column USADDAIN.TXX12SUSTENTOACE.FEC_MODIF is
'Fecha de modificaci�n';

comment on column USADDAIN.TXX12SUSTENTOACE.IND_DEL is
'Indicador Eliminado';

alter table USADDAIN.TXX12SUSTENTOACE
   add constraint PK_TXX12 primary key (NUM_SECACE, NUM_SECSUSTENTO);

/*==============================================================*/
/* Index: IN01TXX12                                             */
/*==============================================================*/
create index USADDAIN.IN01TXX12 on USADDAIN.TXX12SUSTENTOACE (
   NUM_SECACE ASC
);

grant INSERT,SELECT,UPDATE on USADDAIN.TXX12SUSTENTOACE to RLDAIN;

grant SELECT on USADDAIN.TXX12SUSTENTOACE to RLDAINC;

/*==============================================================*/
/* Table: TXX13TIPOACCIONACE                                    */
/*==============================================================*/
create table USADDAIN.TXX13TIPOACCIONACE 
(
   NUM_SECACE           NUMBER(12)           not null,
   COD_TIPOACCION       VARCHAR2(2)          not null,
   COD_USUREGIS         VARCHAR2(19)         default ' ',
   FEC_REGIS            DATE                 default SYSDATE,
   COD_USUMODIF         VARCHAR2(19)         default ' ',
   FEC_MODIF            DATE                 default TO_DATE( '01/01/0001','DD/MM/YYYY'),
   IND_DEL              CHAR(1)              default '0'
);

comment on table USADDAIN.TXX13TIPOACCIONACE is
'Tipo de Accion de Control';

comment on column USADDAIN.TXX13TIPOACCIONACE.COD_TIPOACCION is
'Tipo de Acci�n';

comment on column USADDAIN.TXX13TIPOACCIONACE.COD_USUREGIS is
'Usuario Registro';

comment on column USADDAIN.TXX13TIPOACCIONACE.FEC_REGIS is
'Fecha Registro';

comment on column USADDAIN.TXX13TIPOACCIONACE.COD_USUMODIF is
'Usuario de modificaci�n';

comment on column USADDAIN.TXX13TIPOACCIONACE.FEC_MODIF is
'Fecha de modificaci�n';

comment on column USADDAIN.TXX13TIPOACCIONACE.IND_DEL is
'Indicador Eliminado';

alter table USADDAIN.TXX13TIPOACCIONACE
   add constraint PK_TXX13 primary key (NUM_SECACE, COD_TIPOACCION);

/*==============================================================*/
/* Index: IN01TXX13                                             */
/*==============================================================*/
create index USADDAIN.IN01TXX13 on USADDAIN.TXX13TIPOACCIONACE (
   NUM_SECACE ASC
);

grant INSERT,SELECT,UPDATE on USADDAIN.TXX13TIPOACCIONACE to RLDAIN;

grant SELECT on USADDAIN.TXX13TIPOACCIONACE to RLDAINC;

/*==============================================================*/
/* Table: TXX14ACTAACE                                          */
/*==============================================================*/
create table USADDAIN.TXX14ACTAACE 
(
   NUM_SECACE           NUMBER(12)           not null,
   COD_TIPOACCION       VARCHAR2(2)          not null,
   NUM_SECACTA          NUMBER(6)            not null,
   COD_ADUANA           VARCHAR2(3),
   COD_PUESTOCONTROL    VARCHAR2(6),
   ANN_ACTA             NUMBER(4),
   NUM_ACTA             VARCHAR2(6),
   COD_DOCUMENTO        VARCHAR2(4),
   COD_TIPOACTA         VARCHAR2(4),
   COD_USUREGIS         VARCHAR2(19)         default ' ',
   FEC_REGIS            DATE                 default SYSDATE,
   COD_USUMODIF         VARCHAR2(19)         default ' ',
   FEC_MODIF            DATE                 default TO_DATE( '01/01/0001','DD/MM/YYYY'),
   IND_DEL              CHAR(1)              default '0'
);

comment on column USADDAIN.TXX14ACTAACE.COD_TIPOACCION is
'Tipo de Acci�n';

comment on column USADDAIN.TXX14ACTAACE.COD_USUREGIS is
'Usuario Registro';

comment on column USADDAIN.TXX14ACTAACE.FEC_REGIS is
'Fecha Registro';

comment on column USADDAIN.TXX14ACTAACE.COD_USUMODIF is
'Usuario de modificaci�n';

comment on column USADDAIN.TXX14ACTAACE.FEC_MODIF is
'Fecha de modificaci�n';

comment on column USADDAIN.TXX14ACTAACE.IND_DEL is
'Indicador Eliminado';

alter table USADDAIN.TXX14ACTAACE
   add constraint PK_TXX14 primary key (NUM_SECACE, COD_TIPOACCION, NUM_SECACTA);

/*==============================================================*/
/* Index: IN01TXX14                                             */
/*==============================================================*/
create index USADDAIN.IN01TXX14 on USADDAIN.TXX14ACTAACE (
   NUM_SECACE ASC,
   COD_TIPOACCION ASC
);

grant INSERT,SELECT,UPDATE on USADDAIN.TXX14ACTAACE to RLDAIN;

grant SELECT on USADDAIN.TXX14ACTAACE to RLDAINC;

/*==============================================================*/
/* Table: TXX15ACCESOOPCACE                                     */
/*==============================================================*/
create table USADDAIN.TXX15ACCESOOPCACE 
(
   NUM_SECACCESO        NUMBER(6)            not null,
   NUM_SECACE           NUMBER(12),
   COD_TIPOACCESO       VARCHAR2(2),
   COD_USUCONSULTA      VARCHAR2(19),
   FEC_CONSULTAINI      DATE,
   FEC_CONSULTAFIN      DATE,
   COD_USUREGIS         VARCHAR2(19)         default ' ',
   FEC_REGIS            DATE                 default SYSDATE,
   COD_USUMODIF         VARCHAR2(19)         default ' ',
   FEC_MODIF            DATE                 default TO_DATE( '01/01/0001','DD/MM/YYYY'),
   IND_DEL              CHAR(1)              default '0'
);

comment on column USADDAIN.TXX15ACCESOOPCACE.COD_USUREGIS is
'Usuario Registro';

comment on column USADDAIN.TXX15ACCESOOPCACE.FEC_REGIS is
'Fecha Registro';

comment on column USADDAIN.TXX15ACCESOOPCACE.COD_USUMODIF is
'Usuario de modificaci�n';

comment on column USADDAIN.TXX15ACCESOOPCACE.FEC_MODIF is
'Fecha de modificaci�n';

comment on column USADDAIN.TXX15ACCESOOPCACE.IND_DEL is
'Indicador Eliminado';

alter table USADDAIN.TXX15ACCESOOPCACE
   add constraint PK_TXX15 primary key (NUM_SECACCESO);

/*==============================================================*/
/* Index: IN01TXX15                                             */
/*==============================================================*/
create index USADDAIN.IN01TXX15 on USADDAIN.TXX15ACCESOOPCACE (
   NUM_SECACE ASC
);

/*==============================================================*/
/* Index: IN02TXX15                                             */
/*==============================================================*/
create index USADDAIN.IN02TXX15 on USADDAIN.TXX15ACCESOOPCACE (
   COD_TIPOACCESO ASC,
   COD_USUCONSULTA ASC
);

grant INSERT,SELECT,UPDATE on USADDAIN.TXX15ACCESOOPCACE to RLDAIN;

grant SELECT on USADDAIN.TXX15ACCESOOPCACE to RLDAINC;

/*==============================================================*/
/* Table: TXXX1CAB_ACE                                          */
/*==============================================================*/
create table USADDAIN.TXXX1CAB_ACE 
(
   NUM_SECACE           NUMBER(12)           not null,
   COD_LUGAR            VARCHAR2(10),
   COD_TIPOLUGAR        VARCHAR2(2),
   NUM_RUCINSPECCION    VARCHAR2(11),
   COD_LOCALANEXO       VARCHAR2(6),
   DES_NOMINSPECCION    VARCHAR2(100),
   DES_DIRINSPECCION    VARCHAR2(100),
   COD_UNIDADSELE       VARCHAR2(4),
   NUM_CORREDOCASOC     NUMBER(12),
   COD_REGIMENASOC      VARCHAR2(2),
   COD_ADUANAASOC       VARCHAR2(3),
   ANN_DOCASOC          NUMBER(4),
   NUM_DOCASOC          VARCHAR2(6),
   COD_VIAASOC          VARCHAR2(2),
   NUM_EQUIPAASOC       VARCHAR2(20),
   NUM_DETALLEASOC      NUMBER(10),
   COD_TIPOREGISTRO     VARCHAR2(2),
   COD_UNIDADORG        VARCHAR2(6),
   COD_ADUANAACE        VARCHAR2(3),
   ANN_ACE              NUMBER(4),
   COD_PUESTOACE        VARCHAR2(6),
   NUM_ACE              VARCHAR2(6),
   COD_FLUJO            VARCHAR2(2),
   COD_ESTADOACE        VARCHAR2(2),
   COD_MOMENTO          VARCHAR2(4),
   FEC_GENERACIONACE    DATE,
   FEC_MOMENTOCOM       DATE,
   FEC_ANULACION        DATE,
   FEC_COMUNICACION     DATE,
   FEC_CONCLUSION       DATE,
   FEC_ASIGNACION       DATE,
   COD_USUANULACION     VARCHAR2(19),
   COD_USUCONCLUSION    VARCHAR2(19),
   COD_USUASIGNACION    VARCHAR2(19),
   DES_ANULACION        VARCHAR2(1000)       default ' ',
   COD_USUREGIS         VARCHAR2(19)         default ' ',
   FEC_REGIS            DATE                 default SYSDATE,
   COD_USUMODIF         VARCHAR2(19)         default ' ',
   FEC_MODIF            DATE                 default TO_DATE( '01/01/0001','DD/MM/YYYY'),
   IND_DEL              CHAR(1)              default '0'
);

comment on table USADDAIN.TXXX1CAB_ACE is
'Accion de Control Extraordinaria';

comment on column USADDAIN.TXXX1CAB_ACE.COD_UNIDADSELE is
'Unidad de Seleccion';

comment on column USADDAIN.TXXX1CAB_ACE.NUM_CORREDOCASOC is
'Numero Correlativo de Documento Asociado';

comment on column USADDAIN.TXXX1CAB_ACE.COD_REGIMENASOC is
'Regimen del Documento Asociado';

comment on column USADDAIN.TXXX1CAB_ACE.COD_ADUANAASOC is
'Aduana del Documento Asociado';

comment on column USADDAIN.TXXX1CAB_ACE.ANN_DOCASOC is
'A�o del Documento Asociado';

comment on column USADDAIN.TXXX1CAB_ACE.NUM_DOCASOC is
'N�mero del Documento Asociado';

comment on column USADDAIN.TXXX1CAB_ACE.COD_VIAASOC is
'Codigo de Via del Documento Asociado';

comment on column USADDAIN.TXXX1CAB_ACE.NUM_EQUIPAASOC is
'Numero de contenedor Asociado';

comment on column USADDAIN.TXXX1CAB_ACE.NUM_DETALLEASOC is
'Detalle Documento de Transporte Asociado';

comment on column USADDAIN.TXXX1CAB_ACE.COD_TIPOREGISTRO is
'Tipo de Registro de ACE

01-AUTOMATICA
02-MANUAL';

comment on column USADDAIN.TXXX1CAB_ACE.COD_UNIDADORG is
'Unidad organizacional';

comment on column USADDAIN.TXXX1CAB_ACE.COD_ADUANAACE is
'Aduana de ACE';

comment on column USADDAIN.TXXX1CAB_ACE.ANN_ACE is
'A�o de ACE';

comment on column USADDAIN.TXXX1CAB_ACE.COD_PUESTOACE is
'Puesto de Control';

comment on column USADDAIN.TXXX1CAB_ACE.NUM_ACE is
'N�mero de ACE';

comment on column USADDAIN.TXXX1CAB_ACE.COD_FLUJO is
'Flujo de Control';

comment on column USADDAIN.TXXX1CAB_ACE.COD_ESTADOACE is
'Estados del ACE:

01-EJECUCION
02-PROGRAMADA
03-CONCLUIDA
99-ANULADA';

comment on column USADDAIN.TXXX1CAB_ACE.COD_MOMENTO is
'Momento de Comunicaci�n';

comment on column USADDAIN.TXXX1CAB_ACE.FEC_MOMENTOCOM is
'Fecha de Comunicaci�n';

comment on column USADDAIN.TXXX1CAB_ACE.FEC_ANULACION is
'Fecha de Anulaci�n';

comment on column USADDAIN.TXXX1CAB_ACE.FEC_COMUNICACION is
'Fecha Notificaci�n';

comment on column USADDAIN.TXXX1CAB_ACE.FEC_CONCLUSION is
'Fecha Conclusion';

comment on column USADDAIN.TXXX1CAB_ACE.FEC_ASIGNACION is
'Fecha de asignaci�n';

comment on column USADDAIN.TXXX1CAB_ACE.COD_USUANULACION is
'Usuario Anulacion';

comment on column USADDAIN.TXXX1CAB_ACE.COD_USUCONCLUSION is
'Usuario Conlusion';

comment on column USADDAIN.TXXX1CAB_ACE.COD_USUREGIS is
'Usuario Registro';

comment on column USADDAIN.TXXX1CAB_ACE.FEC_REGIS is
'Fecha Registro';

comment on column USADDAIN.TXXX1CAB_ACE.COD_USUMODIF is
'Usuario de modificaci�n';

comment on column USADDAIN.TXXX1CAB_ACE.FEC_MODIF is
'Fecha de modificaci�n';

comment on column USADDAIN.TXXX1CAB_ACE.IND_DEL is
'Indicador Eliminado';

alter table USADDAIN.TXXX1CAB_ACE
   add constraint PK_TXXX1 primary key (NUM_SECACE);

/*==============================================================*/
/* Index: IN01TXXX1                                             */
/*==============================================================*/
create index USADDAIN.IN01TXXX1 on USADDAIN.TXXX1CAB_ACE (
   COD_ADUANAACE ASC,
   COD_PUESTOACE ASC,
   ANN_ACE ASC,
   NUM_ACE ASC
);

/*==============================================================*/
/* Index: IN02TXXX1                                             */
/*==============================================================*/
create index USADDAIN.IN02TXXX1 on USADDAIN.TXXX1CAB_ACE (
   NUM_CORREDOCASOC ASC
);

/*==============================================================*/
/* Index: IN03TXXX1                                             */
/*==============================================================*/
create index USADDAIN.IN03TXXX1 on USADDAIN.TXXX1CAB_ACE (
   COD_ADUANAASOC ASC,
   COD_REGIMENASOC ASC,
   ANN_DOCASOC ASC,
   NUM_DOCASOC ASC,
   COD_VIAASOC ASC
);

grant INSERT,SELECT,UPDATE on USADDAIN.TXXX1CAB_ACE to RLDAIN;

grant SELECT on USADDAIN.TXXX1CAB_ACE to RLDAINC;

/*==============================================================*/
/* Table: TXXX4DOCREFACE                                        */
/*==============================================================*/
create table USADDAIN.TXXX4DOCREFACE 
(
   NUM_SECACE           NUMBER(12)           not null,
   NUM_SECREF           NUMBER(6)            not null,
   COD_CATEGORIA        VARCHAR2(2),
   COD_ADUANA           VARCHAR2(3),
   ANN_DOCUMENTO        NUMBER(4),
   NUM_DOCUMENTO        VARCHAR2(6),
   COD_TIPOINTERNO      VARCHAR2(4),
   COD_UNIDADORG        VARCHAR2(6),
   DES_ASUNTO           VARCHAR2(2000),
   COD_USUREGIS         VARCHAR2(19)         default ' ',
   FEC_REGIS            DATE                 default SYSDATE,
   COD_USUMODIF         VARCHAR2(19)         default ' ',
   FEC_MODIF            DATE                 default TO_DATE( '01/01/0001','DD/MM/YYYY'),
   IND_DEL              CHAR(1)              default '0'
);

comment on table USADDAIN.TXXX4DOCREFACE is
'Documentos de Referencia';

comment on column USADDAIN.TXXX4DOCREFACE.NUM_SECREF is
'Secuencia de Documento de Referencia';

comment on column USADDAIN.TXXX4DOCREFACE.COD_CATEGORIA is
'Tipo de Documento de Referencia';

comment on column USADDAIN.TXXX4DOCREFACE.ANN_DOCUMENTO is
'A�o de documento de Referencia';

comment on column USADDAIN.TXXX4DOCREFACE.NUM_DOCUMENTO is
'N�mero de documento de Referencia';

comment on column USADDAIN.TXXX4DOCREFACE.COD_TIPOINTERNO is
'Tipo documento interno';

comment on column USADDAIN.TXXX4DOCREFACE.COD_UNIDADORG is
'Unidad organizacional';

comment on column USADDAIN.TXXX4DOCREFACE.DES_ASUNTO is
'Asunto del Documento de Referencia';

comment on column USADDAIN.TXXX4DOCREFACE.COD_USUREGIS is
'Usuario Registro';

comment on column USADDAIN.TXXX4DOCREFACE.FEC_REGIS is
'Fecha Registro';

comment on column USADDAIN.TXXX4DOCREFACE.COD_USUMODIF is
'Usuario de modificaci�n';

comment on column USADDAIN.TXXX4DOCREFACE.FEC_MODIF is
'Fecha de modificaci�n';

comment on column USADDAIN.TXXX4DOCREFACE.IND_DEL is
'Indicador Eliminado';

alter table USADDAIN.TXXX4DOCREFACE
   add constraint PK_TXXX4 primary key (NUM_SECACE, NUM_SECREF);

/*==============================================================*/
/* Index: IN01TXXX4                                             */
/*==============================================================*/
create index USADDAIN.IN01TXXX4 on USADDAIN.TXXX4DOCREFACE (
   NUM_SECACE ASC
);

/*==============================================================*/
/* Index: IN02TXXX4                                             */
/*==============================================================*/
create index USADDAIN.IN02TXXX4 on USADDAIN.TXXX4DOCREFACE (
   COD_ADUANA ASC,
   ANN_DOCUMENTO ASC,
   NUM_DOCUMENTO ASC
);

grant INSERT,SELECT,UPDATE on USADDAIN.TXXX4DOCREFACE to RLDAIN;

grant SELECT on USADDAIN.TXXX4DOCREFACE to RLDAINC;

/*==============================================================*/
/* Table: TXXX5OPERADORACE                                      */
/*==============================================================*/
create table USADDAIN.TXXX5OPERADORACE 
(
   NUM_SECACE           NUMBER(12)           not null,
   NUM_SECOPERADOR      NUMBER(6)            not null,
   COD_TIPOOPERADOR     VARCHAR2(2),
   COD_TIPODOCUMENTO    VARCHAR2(2),
   NUM_DOCUMENTO        VARCHAR2(6),
   COD_USUREGIS         VARCHAR2(19)         default ' ',
   FEC_REGIS            DATE                 default SYSDATE,
   COD_USUMODIF         VARCHAR2(19)         default ' ',
   FEC_MODIF            DATE                 default TO_DATE( '01/01/0001','DD/MM/YYYY'),
   IND_DEL              CHAR(1)              default '0'
);

comment on table USADDAIN.TXXX5OPERADORACE is
'Operadores a Comunicar';

comment on column USADDAIN.TXXX5OPERADORACE.NUM_SECOPERADOR is
'Secuencia de Operador';

comment on column USADDAIN.TXXX5OPERADORACE.COD_TIPOOPERADOR is
'Tipo de Operador';

comment on column USADDAIN.TXXX5OPERADORACE.COD_TIPODOCUMENTO is
'Tipo de Documento de Identidad';

comment on column USADDAIN.TXXX5OPERADORACE.NUM_DOCUMENTO is
'N�mero de documento de Referencia';

comment on column USADDAIN.TXXX5OPERADORACE.COD_USUREGIS is
'Usuario Registro';

comment on column USADDAIN.TXXX5OPERADORACE.FEC_REGIS is
'Fecha Registro';

comment on column USADDAIN.TXXX5OPERADORACE.COD_USUMODIF is
'Usuario de modificaci�n';

comment on column USADDAIN.TXXX5OPERADORACE.FEC_MODIF is
'Fecha de modificaci�n';

comment on column USADDAIN.TXXX5OPERADORACE.IND_DEL is
'Indicador Eliminado';

alter table USADDAIN.TXXX5OPERADORACE
   add constraint PK_TXXX5 primary key (NUM_SECACE, NUM_SECOPERADOR);

/*==============================================================*/
/* Index: IN01TXXX5                                             */
/*==============================================================*/
create index USADDAIN.IN01TXXX5 on USADDAIN.TXXX5OPERADORACE (
   NUM_SECACE ASC
);

grant INSERT,SELECT,UPDATE on USADDAIN.TXXX5OPERADORACE to RLDAIN;

grant SELECT on USADDAIN.TXXX5OPERADORACE to RLDAINC;

/*==============================================================*/
/* Table: TXXX7PROCESOACE                                       */
/*==============================================================*/
create table USADDAIN.TXXX7PROCESOACE 
(
   NUM_PROCESO          NUMBER(12)           not null,
   NUM_SECACE           NUMBER(12),
   COD_UNIDADSELE       VARCHAR2(4),
   NUM_CORREDOCASOC     NUMBER(12),
   COD_REGIMENASOC      VARCHAR2(2),
   COD_ADUANAASOC       VARCHAR2(3),
   ANN_DOCASOC          NUMBER(4),
   NUM_DOCASOC          VARCHAR2(6),
   COD_VIAASOC          VARCHAR2(2),
   NUM_EQUIPAASOC       VARCHAR2(20),
   NUM_DETALLEASOC      NUMBER(10),
   COD_ESTADOPRO        VARCHAR2(2),
   COD_TIPOPRO          VARCHAR2(2),
   COD_RESULTADOPRO     VARCHAR2(2),
   COD_MOMENTO          VARCHAR2(4),
   COD_FLUJO            VARCHAR2(2),
   FEC_RECEPCION        DATE,
   FEC_INICIOPRO        DATE,
   FEC_FINPRO           DATE,
   COD_CRITERIO         VARCHAR2(2),
   COD_TIPOAFORO        VARCHAR2(1),
   COD_MOTIVOAFORO      VARCHAR2(2),
   NUM_INTENTOS         NUMBER(3),
   DES_RESPUESTA        VARCHAR2(4000),
   NUM_CORREDOCREL      NUMBER(12),
   FEC_INVOCACIONASIG   DATE,
   FEC_RESPUESTAASIG    DATE,
   COD_USUREGIS         VARCHAR2(19)         default ' ',
   FEC_REGIS            DATE                 default SYSDATE,
   COD_USUMODIF         VARCHAR2(19)         default ' ',
   FEC_MODIF            DATE                 default TO_DATE( '01/01/0001','DD/MM/YYYY'),
   IND_DEL              CHAR(1)              default '0'
);

comment on table USADDAIN.TXXX7PROCESOACE is
'Registros a procesar para la asignacion de canal y posterior generaci�n del ACE';

comment on column USADDAIN.TXXX7PROCESOACE.COD_UNIDADSELE is
'Unidad de Seleccion';

comment on column USADDAIN.TXXX7PROCESOACE.NUM_CORREDOCASOC is
'Numero Correlativo de Documento Asociado';

comment on column USADDAIN.TXXX7PROCESOACE.COD_REGIMENASOC is
'Regimen del Documento Asociado';

comment on column USADDAIN.TXXX7PROCESOACE.COD_ADUANAASOC is
'Aduana del Documento Asociado';

comment on column USADDAIN.TXXX7PROCESOACE.ANN_DOCASOC is
'A�o del Documento Asociado';

comment on column USADDAIN.TXXX7PROCESOACE.NUM_DOCASOC is
'N�mero del Documento Asociado';

comment on column USADDAIN.TXXX7PROCESOACE.COD_VIAASOC is
'Codigo de Via del Documento Asociado';

comment on column USADDAIN.TXXX7PROCESOACE.NUM_EQUIPAASOC is
'Numero de contenedor Asociado';

comment on column USADDAIN.TXXX7PROCESOACE.NUM_DETALLEASOC is
'Detalle Documento de Transporte Asociado';

comment on column USADDAIN.TXXX7PROCESOACE.COD_ESTADOPRO is
'Estado del proceso:

00-REGISTRADO
01-PROCESADO
23-EN PROCESO
24-PROCESADO CON ERROR';

comment on column USADDAIN.TXXX7PROCESOACE.COD_TIPOPRO is
'C�digo de tipo de proceso:

01-Transmision del RIT';

comment on column USADDAIN.TXXX7PROCESOACE.COD_MOMENTO is
'Momento de Comunicaci�n';

comment on column USADDAIN.TXXX7PROCESOACE.COD_FLUJO is
'Flujo de Control';

comment on column USADDAIN.TXXX7PROCESOACE.FEC_INICIOPRO is
'Fecha Inicio Proceso';

comment on column USADDAIN.TXXX7PROCESOACE.FEC_FINPRO is
'Fecha Termino Proceso';

comment on column USADDAIN.TXXX7PROCESOACE.COD_CRITERIO is
'Criterio Canal Asignado';

comment on column USADDAIN.TXXX7PROCESOACE.COD_TIPOAFORO is
'Codigo Tipo Aforo';

comment on column USADDAIN.TXXX7PROCESOACE.COD_MOTIVOAFORO is
'Motivo Aforo';

comment on column USADDAIN.TXXX7PROCESOACE.NUM_INTENTOS is
'Numero de intentos realizados por el proceso';

comment on column USADDAIN.TXXX7PROCESOACE.DES_RESPUESTA is
'Respuesta del proceso de asignaci�n';

comment on column USADDAIN.TXXX7PROCESOACE.NUM_CORREDOCREL is
'Correlativo de unidad de seleccion';

comment on column USADDAIN.TXXX7PROCESOACE.FEC_INVOCACIONASIG is
'Fecha de invocacion de canal';

comment on column USADDAIN.TXXX7PROCESOACE.FEC_RESPUESTAASIG is
'Fecha de respuesta de canal';

comment on column USADDAIN.TXXX7PROCESOACE.COD_USUREGIS is
'Usuario Registro';

comment on column USADDAIN.TXXX7PROCESOACE.FEC_REGIS is
'Fecha Registro';

comment on column USADDAIN.TXXX7PROCESOACE.COD_USUMODIF is
'Usuario de modificaci�n';

comment on column USADDAIN.TXXX7PROCESOACE.FEC_MODIF is
'Fecha de modificaci�n';

comment on column USADDAIN.TXXX7PROCESOACE.IND_DEL is
'Indicador Eliminado';

alter table USADDAIN.TXXX7PROCESOACE
   add constraint PK_TXXX7 primary key (NUM_PROCESO);

/*==============================================================*/
/* Index: IN01TXXX7                                             */
/*==============================================================*/
create index USADDAIN.IN01TXXX7 on USADDAIN.TXXX7PROCESOACE (
   NUM_SECACE ASC
);

/*==============================================================*/
/* Index: IN02TXXX7                                             */
/*==============================================================*/
create index USADDAIN.IN02TXXX7 on USADDAIN.TXXX7PROCESOACE (
   NUM_CORREDOCASOC ASC
);

/*==============================================================*/
/* Index: IN03TXXX7                                             */
/*==============================================================*/
create index USADDAIN.IN03TXXX7 on USADDAIN.TXXX7PROCESOACE (
   COD_ADUANAASOC ASC,
   ANN_DOCASOC ASC,
   NUM_DOCASOC ASC,
   COD_REGIMENASOC ASC,
   COD_VIAASOC ASC
);

grant INSERT,SELECT,UPDATE on USADDAIN.TXXX7PROCESOACE to RLDAIN;

grant SELECT on USADDAIN.TXXX7PROCESOACE to RLDAINC;

/*==============================================================*/
/* Table: TXXX8ETAPAACE                                         */
/*==============================================================*/
create table USADDAIN.TXXX8ETAPAACE 
(
   NUM_SECACE           NUMBER(12)           not null,
   NUM_SECETAPA         NUMBER(6)            not null,
   COD_ETAPA            VARCHAR2(2),
   COD_ESTADOACE        VARCHAR2(2),
   FEC_ETAPA            DATE,
   DES_OBSERVACION      VARCHAR2(1000),
   COD_USUREGIS         VARCHAR2(19)         default ' ',
   FEC_REGIS            DATE                 default SYSDATE,
   COD_USUMODIF         VARCHAR2(19)         default ' ',
   FEC_MODIF            DATE                 default TO_DATE( '01/01/0001','DD/MM/YYYY'),
   IND_DEL              CHAR(1)              default '0'
);

comment on table USADDAIN.TXXX8ETAPAACE is
'Etapa Accion de Control';

comment on column USADDAIN.TXXX8ETAPAACE.NUM_SECETAPA is
'Correlativo de etapa';

comment on column USADDAIN.TXXX8ETAPAACE.COD_ETAPA is
'C�digo de etapa';

comment on column USADDAIN.TXXX8ETAPAACE.COD_ESTADOACE is
'Estados del ACE:

01-EJECUCION
02-PROGRAMADA
03-CONCLUIDA
99-ANULADA';

comment on column USADDAIN.TXXX8ETAPAACE.FEC_ETAPA is
'Fecha de etapa';

comment on column USADDAIN.TXXX8ETAPAACE.DES_OBSERVACION is
'Observaci�n de etapa';

comment on column USADDAIN.TXXX8ETAPAACE.COD_USUREGIS is
'Usuario Registro';

comment on column USADDAIN.TXXX8ETAPAACE.FEC_REGIS is
'Fecha Registro';

comment on column USADDAIN.TXXX8ETAPAACE.COD_USUMODIF is
'Usuario de modificaci�n';

comment on column USADDAIN.TXXX8ETAPAACE.FEC_MODIF is
'Fecha de modificaci�n';

comment on column USADDAIN.TXXX8ETAPAACE.IND_DEL is
'Indicador Eliminado';

alter table USADDAIN.TXXX8ETAPAACE
   add constraint PK_TXXX8 primary key (NUM_SECACE, NUM_SECETAPA);

/*==============================================================*/
/* Index: IN01TXXX8                                             */
/*==============================================================*/
create index USADDAIN.IN01TXXX8 on USADDAIN.TXXX8ETAPAACE (
   NUM_SECACE ASC
);

grant INSERT,SELECT,UPDATE on USADDAIN.TXXX8ETAPAACE to RLDAIN;

grant SELECT on USADDAIN.TXXX8ETAPAACE to RLDAINC;

/*==============================================================*/
/* Table: TXXX9COMUNICAACE                                      */
/*==============================================================*/
create table USADDAIN.TXXX9COMUNICAACE 
(
   NUM_SECCOMUNIC       NUMBER(6)            not null,
   NUM_SECACE           NUMBER(12),
   COD_TIPOCOMUNIC      VARCHAR2(2),
   COD_TIPODESTINO      VARCHAR2(2),
   FEC_ENVIO            DATE,
   NUM_TICKETAVISO      NUMBER(16),
   COD_USUREGIS         VARCHAR2(19)         default ' ',
   FEC_REGIS            DATE                 default SYSDATE,
   COD_USUMODIF         VARCHAR2(19)         default ' ',
   FEC_MODIF            DATE                 default TO_DATE( '01/01/0001','DD/MM/YYYY'),
   IND_DEL              CHAR(1)              default '0'
);

comment on table USADDAIN.TXXX9COMUNICAACE is
'Notificacion de Accion de Control';

comment on column USADDAIN.TXXX9COMUNICAACE.NUM_SECCOMUNIC is
'Secuencia de notificaci�n';

comment on column USADDAIN.TXXX9COMUNICAACE.COD_TIPOCOMUNIC is
'Tipo de notificaci�n';

comment on column USADDAIN.TXXX9COMUNICAACE.COD_TIPODESTINO is
'Tipo destino de notificaci�n

01-CORREO
02-BUZON SOL';

comment on column USADDAIN.TXXX9COMUNICAACE.FEC_ENVIO is
'Fecha de envio';

comment on column USADDAIN.TXXX9COMUNICAACE.NUM_TICKETAVISO is
'Ticket de aviso electronico';

comment on column USADDAIN.TXXX9COMUNICAACE.COD_USUREGIS is
'Usuario Registro';

comment on column USADDAIN.TXXX9COMUNICAACE.FEC_REGIS is
'Fecha Registro';

comment on column USADDAIN.TXXX9COMUNICAACE.COD_USUMODIF is
'Usuario de modificaci�n';

comment on column USADDAIN.TXXX9COMUNICAACE.FEC_MODIF is
'Fecha de modificaci�n';

comment on column USADDAIN.TXXX9COMUNICAACE.IND_DEL is
'Indicador Eliminado';

alter table USADDAIN.TXXX9COMUNICAACE
   add constraint PK_TXXX9 primary key (NUM_SECCOMUNIC);

/*==============================================================*/
/* Index: IN01TXXX9                                             */
/*==============================================================*/
create index USADDAIN.IN01TXXX9 on USADDAIN.TXXX9COMUNICAACE (
   NUM_SECACE ASC
);

grant INSERT,SELECT,UPDATE on USADDAIN.TXXX9COMUNICAACE to RLDAIN;

grant SELECT on USADDAIN.TXXX9COMUNICAACE to RLDAINC;

alter table USADDAIN.TXX10ASIGNACIONACE
   add constraint FK01_TXX10_TXXX1 foreign key (NUM_SECACE)
      references USADDAIN.TXXX1CAB_ACE (NUM_SECACE);

alter table USADDAIN.TXX12SUSTENTOACE
   add constraint FK01_TXX12_TXXX1 foreign key (NUM_SECACE)
      references USADDAIN.TXXX1CAB_ACE (NUM_SECACE);

alter table USADDAIN.TXX13TIPOACCIONACE
   add constraint FK01_TXX13_TXXX1 foreign key (NUM_SECACE)
      references USADDAIN.TXXX1CAB_ACE (NUM_SECACE);

alter table USADDAIN.TXX14ACTAACE
   add constraint FK01_TXX14_TXX13 foreign key (NUM_SECACE, COD_TIPOACCION)
      references USADDAIN.TXX13TIPOACCIONACE (NUM_SECACE, COD_TIPOACCION);

alter table USADDAIN.TXX15ACCESOOPCACE
   add constraint FK01_TXX15_TXXX1 foreign key (NUM_SECACE)
      references USADDAIN.TXXX1CAB_ACE (NUM_SECACE);

alter table USADDAIN.TXXX4DOCREFACE
   add constraint FK01_TXXX4_TXXX1 foreign key (NUM_SECACE)
      references USADDAIN.TXXX1CAB_ACE (NUM_SECACE);

alter table USADDAIN.TXXX5OPERADORACE
   add constraint FK01_TXXX5_TXXX1 foreign key (NUM_SECACE)
      references USADDAIN.TXXX1CAB_ACE (NUM_SECACE);

alter table USADDAIN.TXXX7PROCESOACE
   add constraint FK01_TXXX7_TXXX1 foreign key (NUM_SECACE)
      references USADDAIN.TXXX1CAB_ACE (NUM_SECACE);

alter table USADDAIN.TXXX8ETAPAACE
   add constraint FK01_TXXX8_TXXX1 foreign key (NUM_SECACE)
      references USADDAIN.TXXX1CAB_ACE (NUM_SECACE);

alter table USADDAIN.TXXX9COMUNICAACE
   add constraint FK01_TXXX9_TXXX1 foreign key (NUM_SECACE)
      references USADDAIN.TXXX1CAB_ACE (NUM_SECACE);

/*==============================================================*/
/* Synonym: SECAB_ACE                                           */
/*==============================================================*/
create or replace public synonym SECAB_ACE 
   for SECAB_ACE;

/*==============================================================*/
/* Synonym: SENUMACE0190300                                     */
/*==============================================================*/
create or replace public synonym SENUMACE0190300 
   for SENUMACE0190300;

/*==============================================================*/
/* Synonym: SEPROCESOACE                                        */
/*==============================================================*/
create or replace public synonym SEPROCESOACE 
   for SEPROCESOACE;

/*==============================================================*/
/* Synonym: ACCESOOPCACE                                        */
/*==============================================================*/
create or replace public synonym ACCESOOPCACE 
   for USADDAIN.TXX15ACCESOOPCACE;

/*==============================================================*/
/* Synonym: ACTAACE                                             */
/*==============================================================*/
create or replace public synonym ACTAACE 
   for USADDAIN.TXX14ACTAACE;

/*==============================================================*/
/* Synonym: ASIGNACIONACE                                       */
/*==============================================================*/
create or replace public synonym ASIGNACIONACE 
   for USADDAIN.TXX10ASIGNACIONACE;

/*==============================================================*/
/* Synonym: CAB_ACE                                             */
/*==============================================================*/
create or replace public synonym CAB_ACE 
   for USADDAIN.TXXX1CAB_ACE;

/*==============================================================*/
/* Synonym: COMUNICAACE                                         */
/*==============================================================*/
create or replace public synonym COMUNICAACE 
   for USADDAIN.TXXX9COMUNICAACE;

/*==============================================================*/
/* Synonym: DOCREFACE                                           */
/*==============================================================*/
create or replace public synonym DOCREFACE 
   for USADDAIN.TXXX4DOCREFACE;

/*==============================================================*/
/* Synonym: ETAPAACE                                            */
/*==============================================================*/
create or replace public synonym ETAPAACE 
   for USADDAIN.TXXX8ETAPAACE;

/*==============================================================*/
/* Synonym: OPERADORACE                                         */
/*==============================================================*/
create or replace public synonym OPERADORACE 
   for USADDAIN.TXXX5OPERADORACE;

/*==============================================================*/
/* Synonym: PROCESOACE                                          */
/*==============================================================*/
create or replace public synonym PROCESOACE 
   for USADDAIN.TXXX7PROCESOACE;

/*==============================================================*/
/* Synonym: SUSTENTOACE                                         */
/*==============================================================*/
create or replace public synonym SUSTENTOACE 
   for USADDAIN.TXX12SUSTENTOACE;

/*==============================================================*/
/* Synonym: TIPOACCIONACE                                       */
/*==============================================================*/
create or replace public synonym TIPOACCIONACE 
   for USADDAIN.TXX13TIPOACCIONACE;

