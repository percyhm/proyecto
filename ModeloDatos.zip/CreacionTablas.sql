/*==============================================================*/
/* DBMS name:      ORACLE Version 11g                           */
/* Created on:     3/01/2020 14:35:29                           */
/*==============================================================*/


create sequence SEACCIONCONTROL
increment by 1
start with 1
 maxvalue 1.000E+27
nocycle
 nocache
noorder;

grant SELECT on SEACCIONCONTROL to RLDAIN;

create sequence SEPROCESOACCION
increment by 1
start with 1
 maxvalue 1.000E+27
nocycle
 nocache
noorder;

grant SELECT on SEPROCESOACCION to RLDAIN;

/*==============================================================*/
/* Table: TXX10ACCIONASIGNA                                     */
/*==============================================================*/
create table USADDAIN.TXX10ACCIONASIGNA 
(
   NUM_SECASIGNACION    NUMBER(6)            not null,
   NUM_SECACCION        NUMBER(10),
   COD_FUNCIONARIO      VARCHAR2(6),
   FEC_ASIGNACION       DATE,
   FEC_INICIOREV        DATE,
   FEC_FINREV           DATE,
   COD_ESTADOREV        VARCHAR2(2),
   DES_MOTIVO           VARCHAR2(1000),
   COD_USUREGIS         VARCHAR2(19),
   FEC_REGIS            DATE                 default SYSDATE,
   COD_USUMODIF         VARCHAR2(19),
   FEC_MODIF            DATE                 default TO_DATE( '01/01/0001','DD/MM/YYYY'),
   IND_DEL              CHAR(1)
);

comment on table USADDAIN.TXX10ACCIONASIGNA is
'Asignacion Especialista';

comment on column USADDAIN.TXX10ACCIONASIGNA.NUM_SECASIGNACION is
'Secuencia de asignaci�n';

comment on column USADDAIN.TXX10ACCIONASIGNA.COD_FUNCIONARIO is
'C�digo de funcionario';

comment on column USADDAIN.TXX10ACCIONASIGNA.FEC_ASIGNACION is
'Fecha de asignaci�n';

comment on column USADDAIN.TXX10ACCIONASIGNA.FEC_INICIOREV is
'Fecha de inicio de revision';

comment on column USADDAIN.TXX10ACCIONASIGNA.FEC_FINREV is
'Fecha fin de revisi�n';

comment on column USADDAIN.TXX10ACCIONASIGNA.COD_ESTADOREV is
'Estado de la revisi�n';

comment on column USADDAIN.TXX10ACCIONASIGNA.DES_MOTIVO is
'Motivo de la asignaci�n';

comment on column USADDAIN.TXX10ACCIONASIGNA.COD_USUREGIS is
'Usuario Registro';

comment on column USADDAIN.TXX10ACCIONASIGNA.FEC_REGIS is
'Fecha Registro';

comment on column USADDAIN.TXX10ACCIONASIGNA.COD_USUMODIF is
'Usuario de modificaci�n';

comment on column USADDAIN.TXX10ACCIONASIGNA.FEC_MODIF is
'Fecha de modificaci�n';

comment on column USADDAIN.TXX10ACCIONASIGNA.IND_DEL is
'Indicador Eliminado';

alter table USADDAIN.TXX10ACCIONASIGNA
   add constraint PK_TXX10 primary key (NUM_SECASIGNACION);

/*==============================================================*/
/* Index: IN01TXX10                                             */
/*==============================================================*/
create index USADDAIN.IN01TXX10 on USADDAIN.TXX10ACCIONASIGNA (
   NUM_SECACCION ASC
);

grant INSERT,SELECT,UPDATE on USADDAIN.TXX10ACCIONASIGNA to RLDAIN;

grant SELECT on USADDAIN.TXX10ACCIONASIGNA to RLDAINC;

/*==============================================================*/
/* Table: TXX12ACCIONSUSTENT                                    */
/*==============================================================*/
create table USADDAIN.TXX12ACCIONSUSTENT 
(
   NUM_SECACCION        NUMBER(10)           not null,
   NUM_SECSUSTENTO      NUMBER(6)            not null,
   COD_FRAUDE           VARCHAR2(2),
   COD_MOTIVO           VARCHAR2(50),
   DES_JUSTIFICACION    VARCHAR2(2000),
   COD_MOMENTO          VARCHAR2(2),
   COD_USUREGIS         VARCHAR2(19),
   FEC_REGIS            DATE                 default SYSDATE,
   COD_USUMODIF         VARCHAR2(19),
   FEC_MODIF            DATE                 default TO_DATE( '01/01/0001','DD/MM/YYYY'),
   IND_DEL              CHAR(1)
);

comment on table USADDAIN.TXX12ACCIONSUSTENT is
'Motivo de Sustento';

comment on column USADDAIN.TXX12ACCIONSUSTENT.COD_FRAUDE is
'C�digo de Fraude';

comment on column USADDAIN.TXX12ACCIONSUSTENT.COD_MOTIVO is
'C�digo motivo de sustento';

comment on column USADDAIN.TXX12ACCIONSUSTENT.DES_JUSTIFICACION is
'Texto de justificaci�n ingresado';

comment on column USADDAIN.TXX12ACCIONSUSTENT.COD_MOMENTO is
'Momento de Comunicaci�n';

comment on column USADDAIN.TXX12ACCIONSUSTENT.COD_USUREGIS is
'Usuario Registro';

comment on column USADDAIN.TXX12ACCIONSUSTENT.FEC_REGIS is
'Fecha Registro';

comment on column USADDAIN.TXX12ACCIONSUSTENT.COD_USUMODIF is
'Usuario de modificaci�n';

comment on column USADDAIN.TXX12ACCIONSUSTENT.FEC_MODIF is
'Fecha de modificaci�n';

comment on column USADDAIN.TXX12ACCIONSUSTENT.IND_DEL is
'Indicador Eliminado';

alter table USADDAIN.TXX12ACCIONSUSTENT
   add constraint PK_TXX12 primary key (NUM_SECACCION, NUM_SECSUSTENTO);

/*==============================================================*/
/* Index: IN01TXX12                                             */
/*==============================================================*/
create index USADDAIN.IN01TXX12 on USADDAIN.TXX12ACCIONSUSTENT (
   NUM_SECACCION ASC
);

grant INSERT,SELECT,UPDATE on USADDAIN.TXX12ACCIONSUSTENT to RLDAIN;

grant SELECT on USADDAIN.TXX12ACCIONSUSTENT to RLDAINC;

/*==============================================================*/
/* Table: TXX13ACCIONTIPO                                       */
/*==============================================================*/
create table USADDAIN.TXX13ACCIONTIPO 
(
   NUM_SECACCION        NUMBER(10)           not null,
   COD_TIPOACCION       VARCHAR2(2)          not null,
   COD_USUREGIS         VARCHAR2(19),
   FEC_REGIS            DATE                 default SYSDATE,
   COD_USUMODIF         VARCHAR2(19),
   FEC_MODIF            DATE                 default TO_DATE( '01/01/0001','DD/MM/YYYY'),
   IND_DEL              CHAR(1)
);

comment on table USADDAIN.TXX13ACCIONTIPO is
'Tipo de Accion de Control';

comment on column USADDAIN.TXX13ACCIONTIPO.COD_TIPOACCION is
'Tipo de Acci�n';

comment on column USADDAIN.TXX13ACCIONTIPO.COD_USUREGIS is
'Usuario Registro';

comment on column USADDAIN.TXX13ACCIONTIPO.FEC_REGIS is
'Fecha Registro';

comment on column USADDAIN.TXX13ACCIONTIPO.COD_USUMODIF is
'Usuario de modificaci�n';

comment on column USADDAIN.TXX13ACCIONTIPO.FEC_MODIF is
'Fecha de modificaci�n';

comment on column USADDAIN.TXX13ACCIONTIPO.IND_DEL is
'Indicador Eliminado';

alter table USADDAIN.TXX13ACCIONTIPO
   add constraint PK_TXX13 primary key (NUM_SECACCION, COD_TIPOACCION);

/*==============================================================*/
/* Index: IN01TXX13                                             */
/*==============================================================*/
create index USADDAIN.IN01TXX13 on USADDAIN.TXX13ACCIONTIPO (
   NUM_SECACCION ASC
);

grant INSERT,SELECT,UPDATE on USADDAIN.TXX13ACCIONTIPO to RLDAIN;

grant SELECT on USADDAIN.TXX13ACCIONTIPO to RLDAINC;

/*==============================================================*/
/* Table: TXXX1ACCIONCONTROL                                    */
/*==============================================================*/
create table USADDAIN.TXXX1ACCIONCONTROL 
(
   NUM_SECACCION        NUMBER(10)           not null,
   COD_LUGAR            VARCHAR2(10),
   COD_TIPOLUGAR        VARCHAR2(2),
   NUM_RUCINSPECCION    VARCHAR2(11),
   COD_LOCALANEXO       VARCHAR2(6),
   DES_NOMINSPECCION    VARCHAR2(100),
   DES_DIRINSPECCION    VARCHAR2(100),
   COD_TIPOREGISTRO     VARCHAR2(2),
   COD_UNIDADORG        VARCHAR2(6),
   COD_ADUANAACCION     VARCHAR2(3),
   COD_PUESTOACCION     VARCHAR2(6),
   ANN_ACCION           VARCHAR2(4),
   NUM_ACCION           VARCHAR2(6),
   COD_FLUJO            VARCHAR2(2),
   COD_UNIDADSELE       VARCHAR2(4),
   ANN_DOCASOC          NUMBER(4),
   COD_ADUANAASOC       VARCHAR2(3),
   COD_REGIMENASOC      VARCHAR2(2),
   NUM_DOCASOC          VARCHAR2(10),
   COD_VIAASOC          VARCHAR2(2),
   NUM_EQUIPAASOC       VARCHAR2(20),
   NUM_DETALLEASOC      NUMBER(10),
   NUM_CORREDOCASOC     NUMBER(12),
   COD_ESTADOACCION     VARCHAR2(2),
   COD_MOMENTO          VARCHAR2(2),
   FEC_MOMENTOCOM       DATE,
   FEC_ANULACION        DATE,
   FEC_NOTIFICACION     DATE,
   FEC_CONCLUSION       DATE,
   FEC_ASIGNACION       DATE,
   COD_USUANULACION     VARCHAR2(19),
   COD_USUCONLUSION     VARCHAR2(19),
   COD_USUREGIS         VARCHAR2(19),
   COD_USUASIGNACION    VARCHAR2(19),
   FEC_REGIS            DATE                 default SYSDATE,
   COD_USUMODIF         VARCHAR2(19),
   FEC_MODIF            DATE                 default TO_DATE( '01/01/0001','DD/MM/YYYY'),
   IND_DEL              CHAR(1)
);

comment on table USADDAIN.TXXX1ACCIONCONTROL is
'Accion de Control Extraordinaria';

comment on column USADDAIN.TXXX1ACCIONCONTROL.COD_TIPOREGISTRO is
'Tipo de Registro de ACE

01-AUTOMATICA
02-MANUAL';

comment on column USADDAIN.TXXX1ACCIONCONTROL.COD_UNIDADORG is
'Unidad organizacional';

comment on column USADDAIN.TXXX1ACCIONCONTROL.COD_ADUANAACCION is
'Aduana de ACE';

comment on column USADDAIN.TXXX1ACCIONCONTROL.COD_PUESTOACCION is
'Puesto de Control';

comment on column USADDAIN.TXXX1ACCIONCONTROL.ANN_ACCION is
'A�o de ACE';

comment on column USADDAIN.TXXX1ACCIONCONTROL.NUM_ACCION is
'N�mero de ACE';

comment on column USADDAIN.TXXX1ACCIONCONTROL.COD_FLUJO is
'Flujo de Control';

comment on column USADDAIN.TXXX1ACCIONCONTROL.COD_UNIDADSELE is
'Unidad de Seleccion';

comment on column USADDAIN.TXXX1ACCIONCONTROL.ANN_DOCASOC is
'A�o del Documento Asociado';

comment on column USADDAIN.TXXX1ACCIONCONTROL.COD_ADUANAASOC is
'Aduana del Documento Asociado';

comment on column USADDAIN.TXXX1ACCIONCONTROL.COD_REGIMENASOC is
'Regimen del Documento Asociado';

comment on column USADDAIN.TXXX1ACCIONCONTROL.NUM_DOCASOC is
'N�mero del Documento Asociado';

comment on column USADDAIN.TXXX1ACCIONCONTROL.COD_VIAASOC is
'Codigo de Via del Documento Asociado';

comment on column USADDAIN.TXXX1ACCIONCONTROL.NUM_EQUIPAASOC is
'Numero de contenedor Asociado';

comment on column USADDAIN.TXXX1ACCIONCONTROL.NUM_DETALLEASOC is
'Detalle Documento de Transporte Asociado';

comment on column USADDAIN.TXXX1ACCIONCONTROL.NUM_CORREDOCASOC is
'Numero Correlativo de Documento Asociado';

comment on column USADDAIN.TXXX1ACCIONCONTROL.COD_ESTADOACCION is
'Estados del ACE:

01-EJECUCION
02-PROGRAMADA
03-CONCLUIDA
99-ANULADA';

comment on column USADDAIN.TXXX1ACCIONCONTROL.COD_MOMENTO is
'Momento de Comunicaci�n';

comment on column USADDAIN.TXXX1ACCIONCONTROL.FEC_MOMENTOCOM is
'Fecha de Comunicaci�n';

comment on column USADDAIN.TXXX1ACCIONCONTROL.FEC_ANULACION is
'Fecha de Anulaci�n';

comment on column USADDAIN.TXXX1ACCIONCONTROL.FEC_NOTIFICACION is
'Fecha Notificaci�n';

comment on column USADDAIN.TXXX1ACCIONCONTROL.FEC_CONCLUSION is
'Fecha Conclusion';

comment on column USADDAIN.TXXX1ACCIONCONTROL.COD_USUREGIS is
'Usuario Registro';

comment on column USADDAIN.TXXX1ACCIONCONTROL.FEC_REGIS is
'Fecha Registro';

comment on column USADDAIN.TXXX1ACCIONCONTROL.COD_USUMODIF is
'Usuario de modificaci�n';

comment on column USADDAIN.TXXX1ACCIONCONTROL.FEC_MODIF is
'Fecha de modificaci�n';

comment on column USADDAIN.TXXX1ACCIONCONTROL.IND_DEL is
'Indicador Eliminado';

alter table USADDAIN.TXXX1ACCIONCONTROL
   add constraint PK_TXXX1 primary key (NUM_SECACCION);

/*==============================================================*/
/* Index: IN01TXXX1                                             */
/*==============================================================*/
create index USADDAIN.IN01TXXX1 on USADDAIN.TXXX1ACCIONCONTROL (
   COD_ADUANAACCION ASC,
   COD_PUESTOACCION ASC,
   ANN_ACCION ASC,
   NUM_ACCION ASC
);

grant INSERT,SELECT,UPDATE on USADDAIN.TXXX1ACCIONCONTROL to RLDAIN;

grant SELECT on USADDAIN.TXXX1ACCIONCONTROL to RLDAINC;

/*==============================================================*/
/* Table: TXXX4ACCIONDOCREF                                     */
/*==============================================================*/
create table USADDAIN.TXXX4ACCIONDOCREF 
(
   NUM_SECACCION        NUMBER(10)           not null,
   NUM_SECREF           NUMBER(6)            not null,
   COD_ADUANA           VARCHAR2(3),
   COD_TIPOREF          VARCHAR2(2),
   ANN_DOCUMENTO        VARCHAR2(4),
   NUM_DOCUMENTO        VARCHAR2(6),
   COD_TIPOINTERNO      VARCHAR2(4),
   COD_UNIDADORG        VARCHAR2(6),
   DES_ASUNTO           VARCHAR2(2000),
   COD_USUREGIS         VARCHAR2(19),
   FEC_REGIS            DATE                 default SYSDATE,
   COD_USUMODIF         VARCHAR2(19),
   FEC_MODIF            DATE                 default TO_DATE( '01/01/0001','DD/MM/YYYY'),
   IND_DEL              CHAR(1)
);

comment on table USADDAIN.TXXX4ACCIONDOCREF is
'Documentos de Referencia';

comment on column USADDAIN.TXXX4ACCIONDOCREF.NUM_SECREF is
'Secuencia de Documento de Referencia';

comment on column USADDAIN.TXXX4ACCIONDOCREF.COD_TIPOREF is
'Tipo de Documento de Referencia';

comment on column USADDAIN.TXXX4ACCIONDOCREF.ANN_DOCUMENTO is
'A�o de documento de Referencia';

comment on column USADDAIN.TXXX4ACCIONDOCREF.NUM_DOCUMENTO is
'N�mero de documento de Referencia';

comment on column USADDAIN.TXXX4ACCIONDOCREF.COD_TIPOINTERNO is
'Tipo documento interno';

comment on column USADDAIN.TXXX4ACCIONDOCREF.COD_UNIDADORG is
'Unidad organizacional';

comment on column USADDAIN.TXXX4ACCIONDOCREF.DES_ASUNTO is
'Asunto del Documento de Referencia';

comment on column USADDAIN.TXXX4ACCIONDOCREF.COD_USUREGIS is
'Usuario Registro';

comment on column USADDAIN.TXXX4ACCIONDOCREF.FEC_REGIS is
'Fecha Registro';

comment on column USADDAIN.TXXX4ACCIONDOCREF.COD_USUMODIF is
'Usuario de modificaci�n';

comment on column USADDAIN.TXXX4ACCIONDOCREF.FEC_MODIF is
'Fecha de modificaci�n';

comment on column USADDAIN.TXXX4ACCIONDOCREF.IND_DEL is
'Indicador Eliminado';

alter table USADDAIN.TXXX4ACCIONDOCREF
   add constraint PK_TXXX4 primary key (NUM_SECACCION, NUM_SECREF);

/*==============================================================*/
/* Index: IN01TXXX4                                             */
/*==============================================================*/
create index USADDAIN.IN01TXXX4 on USADDAIN.TXXX4ACCIONDOCREF (
   NUM_SECACCION ASC
);

/*==============================================================*/
/* Index: IN02TXXX4                                             */
/*==============================================================*/
create index USADDAIN.IN02TXXX4 on USADDAIN.TXXX4ACCIONDOCREF (
   COD_ADUANA ASC,
   ANN_DOCUMENTO ASC,
   NUM_DOCUMENTO ASC
);

grant INSERT,SELECT,UPDATE on USADDAIN.TXXX4ACCIONDOCREF to RLDAIN;

grant SELECT on USADDAIN.TXXX4ACCIONDOCREF to RLDAINC;

/*==============================================================*/
/* Table: TXXX5ACCIONOPE                                        */
/*==============================================================*/
create table USADDAIN.TXXX5ACCIONOPE 
(
   NUM_SECACCION        NUMBER(10)           not null,
   NUM_SECOPERADOR      NUMBER(6)            not null,
   COD_TIPOOPERADOR     VARCHAR2(2),
   COD_TIPODOCUMENTO    VARCHAR2(2),
   NUM_DOCUMENTO        VARCHAR2(6),
   COD_USUREGIS         VARCHAR2(19),
   FEC_REGIS            DATE                 default SYSDATE,
   COD_USUMODIF         VARCHAR2(19),
   FEC_MODIF            DATE                 default TO_DATE( '01/01/0001','DD/MM/YYYY'),
   IND_DEL              CHAR(1)
);

comment on table USADDAIN.TXXX5ACCIONOPE is
'Operadores a Comunicar';

comment on column USADDAIN.TXXX5ACCIONOPE.NUM_SECOPERADOR is
'Secuencia de Operador';

comment on column USADDAIN.TXXX5ACCIONOPE.COD_TIPOOPERADOR is
'Tipo de Operador';

comment on column USADDAIN.TXXX5ACCIONOPE.COD_TIPODOCUMENTO is
'Tipo de Documento de Identidad';

comment on column USADDAIN.TXXX5ACCIONOPE.NUM_DOCUMENTO is
'N�mero de documento de Referencia';

comment on column USADDAIN.TXXX5ACCIONOPE.COD_USUREGIS is
'Usuario Registro';

comment on column USADDAIN.TXXX5ACCIONOPE.FEC_REGIS is
'Fecha Registro';

comment on column USADDAIN.TXXX5ACCIONOPE.COD_USUMODIF is
'Usuario de modificaci�n';

comment on column USADDAIN.TXXX5ACCIONOPE.FEC_MODIF is
'Fecha de modificaci�n';

comment on column USADDAIN.TXXX5ACCIONOPE.IND_DEL is
'Indicador Eliminado';

alter table USADDAIN.TXXX5ACCIONOPE
   add constraint PK_TXXX5 primary key (NUM_SECACCION, NUM_SECOPERADOR);

/*==============================================================*/
/* Index: IN01TXXX5                                             */
/*==============================================================*/
create index USADDAIN.IN01TXXX5 on USADDAIN.TXXX5ACCIONOPE (
   NUM_SECACCION ASC
);

grant INSERT,SELECT,UPDATE on USADDAIN.TXXX5ACCIONOPE to RLDAIN;

grant SELECT on USADDAIN.TXXX5ACCIONOPE to RLDAINC;

/*==============================================================*/
/* Table: TXXX7PROCESOACCION                                    */
/*==============================================================*/
create table USADDAIN.TXXX7PROCESOACCION 
(
   NUM_PROCESO          NUMBER(10)           not null,
   NUM_SECACCION        NUMBER(10),
   COD_TIPOPRO          VARCHAR2(2),
   COD_UNIDADSELE       VARCHAR2(4),
   ANN_DOCASOC          NUMBER(4),
   COD_ADUANAASOC       VARCHAR2(3),
   COD_REGIMENASOC      VARCHAR2(2),
   NUM_DOCASOC          VARCHAR2(10),
   COD_VIAASOC          VARCHAR2(2),
   NUM_EQUIPAASOC       VARCHAR2(20),
   NUM_DETALLEASOC      NUMBER(10),
   NUM_CORREDOCASOC     NUMBER(12),
   COD_MOMENTO          VARCHAR2(4),
   NUM_CORREDOC_SEL     NUMBER(12),
   COD_MOTIVOAFORO      VARCHAR2(2),
   COD_TIPOAFORO        VARCHAR2(1),
   COD_CRITERIO         VARCHAR2(2),
   COD_PROCESOASIG      VARCHAR2(10),
   NUM_INTENTOS         NUMBER(6),
   FEC_INICIOPRO        DATE,
   FEC_FINPRO           DATE,
   DES_RESPUESTA        VARCHAR2(4000),
   FEC_INVOCACIONASIG   DATE,
   FEC_RESPUESTAASIG    DATE,
   COD_ESTADOPRO        VARCHAR2(2),
   COD_FLUJO            VARCHAR2(2),
   COD_USUREGIS         VARCHAR2(19),
   FEC_REGIS            DATE                 default SYSDATE,
   COD_USUMODIF         VARCHAR2(19),
   FEC_MODIF            DATE                 default TO_DATE( '01/01/0001','DD/MM/YYYY'),
   IND_DEL              CHAR(1)
);

comment on table USADDAIN.TXXX7PROCESOACCION is
'Registros a procesar para la asignacion de canal y posterior generaci�n del ACE';

comment on column USADDAIN.TXXX7PROCESOACCION.COD_UNIDADSELE is
'Unidad de Seleccion';

comment on column USADDAIN.TXXX7PROCESOACCION.ANN_DOCASOC is
'A�o del Documento Asociado';

comment on column USADDAIN.TXXX7PROCESOACCION.COD_ADUANAASOC is
'Aduana del Documento Asociado';

comment on column USADDAIN.TXXX7PROCESOACCION.COD_REGIMENASOC is
'Regimen del Documento Asociado';

comment on column USADDAIN.TXXX7PROCESOACCION.NUM_DOCASOC is
'N�mero del Documento Asociado';

comment on column USADDAIN.TXXX7PROCESOACCION.COD_VIAASOC is
'Codigo de Via del Documento Asociado';

comment on column USADDAIN.TXXX7PROCESOACCION.NUM_EQUIPAASOC is
'Numero de contenedor Asociado';

comment on column USADDAIN.TXXX7PROCESOACCION.NUM_DETALLEASOC is
'Detalle Documento de Transporte Asociado';

comment on column USADDAIN.TXXX7PROCESOACCION.NUM_CORREDOCASOC is
'Numero Correlativo de Documento Asociado';

comment on column USADDAIN.TXXX7PROCESOACCION.COD_MOMENTO is
'Momento de Comunicaci�n';

comment on column USADDAIN.TXXX7PROCESOACCION.NUM_CORREDOC_SEL is
'Correlativo de unidad de seleccion';

comment on column USADDAIN.TXXX7PROCESOACCION.COD_MOTIVOAFORO is
'Motivo Aforo';

comment on column USADDAIN.TXXX7PROCESOACCION.COD_TIPOAFORO is
'Codigo Tipo Aforo';

comment on column USADDAIN.TXXX7PROCESOACCION.COD_CRITERIO is
'Criterio Canal Asignado';

comment on column USADDAIN.TXXX7PROCESOACCION.COD_PROCESOASIG is
'C�digo del proceso de asignaci�n';

comment on column USADDAIN.TXXX7PROCESOACCION.NUM_INTENTOS is
'Numero de intentos realizados por el proceso';

comment on column USADDAIN.TXXX7PROCESOACCION.FEC_INICIOPRO is
'Fecha Inicio Proceso';

comment on column USADDAIN.TXXX7PROCESOACCION.FEC_FINPRO is
'Fecha Termino Proceso';

comment on column USADDAIN.TXXX7PROCESOACCION.DES_RESPUESTA is
'Respuesta del proceso de asignaci�n';

comment on column USADDAIN.TXXX7PROCESOACCION.FEC_INVOCACIONASIG is
'Fecha de invocacion de canal';

comment on column USADDAIN.TXXX7PROCESOACCION.FEC_RESPUESTAASIG is
'Fecha de respuesta de canal';

comment on column USADDAIN.TXXX7PROCESOACCION.COD_ESTADOPRO is
'Estado del proceso:

00-REGISTRADO
01-PROCESADO
23-EN PROCESO
24-PROCESADO CON ERROR';

comment on column USADDAIN.TXXX7PROCESOACCION.COD_FLUJO is
'Flujo de Control';

comment on column USADDAIN.TXXX7PROCESOACCION.COD_USUREGIS is
'Usuario Registro';

comment on column USADDAIN.TXXX7PROCESOACCION.FEC_REGIS is
'Fecha Registro';

comment on column USADDAIN.TXXX7PROCESOACCION.COD_USUMODIF is
'Usuario de modificaci�n';

comment on column USADDAIN.TXXX7PROCESOACCION.FEC_MODIF is
'Fecha de modificaci�n';

comment on column USADDAIN.TXXX7PROCESOACCION.IND_DEL is
'Indicador Eliminado';

alter table USADDAIN.TXXX7PROCESOACCION
   add constraint PK_TXXX7 primary key (NUM_PROCESO);

/*==============================================================*/
/* Index: IN01TXXX7                                             */
/*==============================================================*/
create index USADDAIN.IN01TXXX7 on USADDAIN.TXXX7PROCESOACCION (
   NUM_SECACCION ASC
);

/*==============================================================*/
/* Index: IN02TXXX7                                             */
/*==============================================================*/
create index USADDAIN.IN02TXXX7 on USADDAIN.TXXX7PROCESOACCION (
   NUM_CORREDOCASOC ASC
);

/*==============================================================*/
/* Index: IN03TXXX7                                             */
/*==============================================================*/
create index USADDAIN.IN03TXXX7 on USADDAIN.TXXX7PROCESOACCION (
   COD_ADUANAASOC ASC,
   ANN_DOCASOC ASC,
   NUM_DOCASOC ASC,
   COD_REGIMENASOC ASC,
   COD_VIAASOC ASC
);

grant INSERT,SELECT,UPDATE on USADDAIN.TXXX7PROCESOACCION to RLDAIN;

grant SELECT on USADDAIN.TXXX7PROCESOACCION to RLDAINC;

/*==============================================================*/
/* Table: TXXX8ACCIONETAPA                                      */
/*==============================================================*/
create table USADDAIN.TXXX8ACCIONETAPA 
(
   NUM_SECACCION        NUMBER(10)           not null,
   NUM_SECETAPA         NUMBER(6)            not null,
   COD_ETAPA            VARCHAR2(2),
   COD_ESTADOACCION     VARCHAR2(2),
   FEC_ETAPA            DATE,
   DES_OBSERVACION      VARCHAR2(1000),
   COD_USUREGIS         VARCHAR2(19),
   FEC_REGIS            DATE                 default SYSDATE,
   COD_USUMODIF         VARCHAR2(19),
   FEC_MODIF            DATE                 default TO_DATE( '01/01/0001','DD/MM/YYYY'),
   IND_DEL              CHAR(1)
);

comment on table USADDAIN.TXXX8ACCIONETAPA is
'Etapa Accion de Control';

comment on column USADDAIN.TXXX8ACCIONETAPA.NUM_SECETAPA is
'Correlativo de etapa';

comment on column USADDAIN.TXXX8ACCIONETAPA.COD_ETAPA is
'C�digo de etapa';

comment on column USADDAIN.TXXX8ACCIONETAPA.COD_ESTADOACCION is
'Estados del ACE:

01-EJECUCION
02-PROGRAMADA
03-CONCLUIDA
99-ANULADA';

comment on column USADDAIN.TXXX8ACCIONETAPA.FEC_ETAPA is
'Fecha de etapa';

comment on column USADDAIN.TXXX8ACCIONETAPA.DES_OBSERVACION is
'Observaci�n de etapa';

comment on column USADDAIN.TXXX8ACCIONETAPA.COD_USUREGIS is
'Usuario Registro';

comment on column USADDAIN.TXXX8ACCIONETAPA.FEC_REGIS is
'Fecha Registro';

comment on column USADDAIN.TXXX8ACCIONETAPA.COD_USUMODIF is
'Usuario de modificaci�n';

comment on column USADDAIN.TXXX8ACCIONETAPA.FEC_MODIF is
'Fecha de modificaci�n';

comment on column USADDAIN.TXXX8ACCIONETAPA.IND_DEL is
'Indicador Eliminado';

alter table USADDAIN.TXXX8ACCIONETAPA
   add constraint PK_TXXX8 primary key (NUM_SECACCION, NUM_SECETAPA);

/*==============================================================*/
/* Index: IN01TXXX8                                             */
/*==============================================================*/
create index USADDAIN.IN01TXXX8 on USADDAIN.TXXX8ACCIONETAPA (
   NUM_SECACCION ASC
);

grant INSERT,SELECT,UPDATE on USADDAIN.TXXX8ACCIONETAPA to RLDAIN;

grant SELECT on USADDAIN.TXXX8ACCIONETAPA to RLDAINC;

/*==============================================================*/
/* Table: TXXX9ACCIONNOTIF                                      */
/*==============================================================*/
create table USADDAIN.TXXX9ACCIONNOTIF 
(
   NUM_SECNOTIFI        NUMBER(6)            not null,
   NUM_SECACCION        NUMBER(10),
   COD_TIPONOTIFI       VARCHAR2(2),
   COD_TIPODESTINO      VARCHAR2(2),
   FEC_ENVIO            DATE,
   NUM_TICKETAVISO      NUMBER(16),
   COD_USUREGIS         VARCHAR2(19),
   FEC_REGIS            DATE                 default SYSDATE,
   COD_USUMODIF         VARCHAR2(19),
   FEC_MODIF            DATE                 default TO_DATE( '01/01/0001','DD/MM/YYYY'),
   IND_DEL              CHAR(1)
);

comment on table USADDAIN.TXXX9ACCIONNOTIF is
'Notificacion de Accion de Control';

comment on column USADDAIN.TXXX9ACCIONNOTIF.NUM_SECNOTIFI is
'Secuencia de notificaci�n';

comment on column USADDAIN.TXXX9ACCIONNOTIF.COD_TIPONOTIFI is
'Tipo de notificaci�n';

comment on column USADDAIN.TXXX9ACCIONNOTIF.COD_TIPODESTINO is
'Tipo destino de notificaci�n

01-CORREO
02-BUZON SOL';

comment on column USADDAIN.TXXX9ACCIONNOTIF.FEC_ENVIO is
'Fecha de envio';

comment on column USADDAIN.TXXX9ACCIONNOTIF.NUM_TICKETAVISO is
'Ticket de aviso electronico';

comment on column USADDAIN.TXXX9ACCIONNOTIF.COD_USUREGIS is
'Usuario Registro';

comment on column USADDAIN.TXXX9ACCIONNOTIF.FEC_REGIS is
'Fecha Registro';

comment on column USADDAIN.TXXX9ACCIONNOTIF.COD_USUMODIF is
'Usuario de modificaci�n';

comment on column USADDAIN.TXXX9ACCIONNOTIF.FEC_MODIF is
'Fecha de modificaci�n';

comment on column USADDAIN.TXXX9ACCIONNOTIF.IND_DEL is
'Indicador Eliminado';

alter table USADDAIN.TXXX9ACCIONNOTIF
   add constraint PK_TXXX9 primary key (NUM_SECNOTIFI);

/*==============================================================*/
/* Index: IN01TXXX9                                             */
/*==============================================================*/
create index USADDAIN.IN01TXXX9 on USADDAIN.TXXX9ACCIONNOTIF (
   NUM_SECACCION ASC
);

grant INSERT,SELECT,UPDATE on USADDAIN.TXXX9ACCIONNOTIF to RLDAIN;

grant SELECT on USADDAIN.TXXX9ACCIONNOTIF to RLDAINC;

alter table USADDAIN.TXX10ACCIONASIGNA
   add constraint FK_TXX10ACC_FK01_TXX1_TXXX1ACC foreign key (NUM_SECACCION)
      references USADDAIN.TXXX1ACCIONCONTROL (NUM_SECACCION);

alter table USADDAIN.TXX12ACCIONSUSTENT
   add constraint FK_TXX12ACC_FK01_TXX1_TXXX1ACC foreign key (NUM_SECACCION)
      references USADDAIN.TXXX1ACCIONCONTROL (NUM_SECACCION);

alter table USADDAIN.TXX13ACCIONTIPO
   add constraint FK_TXX13ACC_FK01_TXX1_TXXX1ACC foreign key (NUM_SECACCION)
      references USADDAIN.TXXX1ACCIONCONTROL (NUM_SECACCION);

alter table USADDAIN.TXXX4ACCIONDOCREF
   add constraint FK_TXXX4ACC_FK01_TXXX_TXXX1ACC foreign key (NUM_SECACCION)
      references USADDAIN.TXXX1ACCIONCONTROL (NUM_SECACCION);

alter table USADDAIN.TXXX5ACCIONOPE
   add constraint FK_TXXX5ACC_FK01_TXXX_TXXX1ACC foreign key (NUM_SECACCION)
      references USADDAIN.TXXX1ACCIONCONTROL (NUM_SECACCION);

alter table USADDAIN.TXXX7PROCESOACCION
   add constraint FK_TXXX7PRO_FK01_TXXX_TXXX1ACC foreign key (NUM_SECACCION)
      references USADDAIN.TXXX1ACCIONCONTROL (NUM_SECACCION);

alter table USADDAIN.TXXX8ACCIONETAPA
   add constraint FK_TXXX8ACC_FK01_TXXX_TXXX1ACC foreign key (NUM_SECACCION)
      references USADDAIN.TXXX1ACCIONCONTROL (NUM_SECACCION);

alter table USADDAIN.TXXX9ACCIONNOTIF
   add constraint FK_TXXX9ACC_FK01_TXXX_TXXX1ACC foreign key (NUM_SECACCION)
      references USADDAIN.TXXX1ACCIONCONTROL (NUM_SECACCION);

/*==============================================================*/
/* Synonym: SEACCIONCONTROL                                     */
/*==============================================================*/
create or replace public synonym SEACCIONCONTROL 
   for SEACCIONCONTROL;

/*==============================================================*/
/* Synonym: SEPROCESOACCION                                     */
/*==============================================================*/
create or replace public synonym SEPROCESOACCION 
   for SEPROCESOACCION;

/*==============================================================*/
/* Synonym: ACCIONASIGNA                                        */
/*==============================================================*/
create or replace public synonym ACCIONASIGNA 
   for USADDAIN.TXX10ACCIONASIGNA;

/*==============================================================*/
/* Synonym: ACCIONCONTROL                                       */
/*==============================================================*/
create or replace public synonym ACCIONCONTROL 
   for USADDAIN.TXXX1ACCIONCONTROL;

/*==============================================================*/
/* Synonym: ACCIONDOCREF                                        */
/*==============================================================*/
create or replace public synonym ACCIONDOCREF 
   for USADDAIN.TXXX4ACCIONDOCREF;

/*==============================================================*/
/* Synonym: ACCIONETAPA                                         */
/*==============================================================*/
create or replace public synonym ACCIONETAPA 
   for USADDAIN.TXXX8ACCIONETAPA;

/*==============================================================*/
/* Synonym: ACCIONNOTIF                                         */
/*==============================================================*/
create or replace public synonym ACCIONNOTIF 
   for USADDAIN.TXXX9ACCIONNOTIF;

/*==============================================================*/
/* Synonym: ACCIONOPE                                           */
/*==============================================================*/
create or replace public synonym ACCIONOPE 
   for USADDAIN.TXXX5ACCIONOPE;

/*==============================================================*/
/* Synonym: ACCIONSUSTENT                                       */
/*==============================================================*/
create or replace public synonym ACCIONSUSTENT 
   for USADDAIN.TXX12ACCIONSUSTENT;

/*==============================================================*/
/* Synonym: ACCIONTIPO                                          */
/*==============================================================*/
create or replace public synonym ACCIONTIPO 
   for USADDAIN.TXX13ACCIONTIPO;

/*==============================================================*/
/* Synonym: PROCESOACCION                                       */
/*==============================================================*/
create or replace public synonym PROCESOACCION 
   for USADDAIN.TXXX7PROCESOACCION;

